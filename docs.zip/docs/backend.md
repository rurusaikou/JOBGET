# 托管服务与匿名统计

后端目录：`/Users/luyang/Documents/project/rolemi-backend-v2.7.0`。本次以本地联调交付，插件统一地址为 `src/shared/backend/config.js` 的 `http://localhost:8787`，未部署公网。

## 反馈接口

插件反馈页提交 `POST /api/feedback` JSON：`installation_id`、`type`、`content`，以及可选岗位快照 `job_id`、`job_title`、`jd_content`、`deep_analysis_result`、`match_result`、`revision_result`、`greeting_result`。选择岗位时会提交当时已生成的结果；不提交简历原文或附件。正文最多 500 字。

相邻后端提供 `POST /api/feedback` 并写入 D1 `feedback` 表。反馈记录可包含用户主动关联岗位的 JD 与已生成工作流结果，用于 Bad Case / Prompt 效果分析；不保存简历原文或附件，且不参加 30 天 metrics 自动清理。

## 本地运行

进入后端目录，先 `npm ci`；没有 `.dev.vars` 时从 `.dev.vars.example` 复制并填写 `AI_API_KEY`，已有文件应保留。执行：

```bash
npx wrangler d1 execute rolemi-metrics --local --file=sql/schema.sql
npx wrangler d1 execute rolemi-metrics --local --file=sql/event-aggregates.sql
npm run dev
```

如果本地已有原两表结构，**只执行一次 `sql/metrics-v2.sql` 升级**，不要把新 schema 当升级脚本；新库执行 schema.sql，不再执行旧表升级；两者均需随后执行 event-aggregates.sql 安装聚合触发器，已有 v2.5 库只需安装该触发器。触发器不回补历史遗漏。默认本地 D1（remote:false）避免开发写远程库。重新加载扩展，新增 alarms 权限及 module service worker 才会生效。

默认使用 RoleMI 后端；用户保存自己的 Base URL、模型和 API Key 后，优先直连用户的 Responses API（仅支持 Responses API）。项目方只在服务端配置 URL / 模型 / Key。

## 数据路径

业务模块 → shared/ai/client.js 转成 Responses → /api/ai → Worker 固定供应商、模型和 Key → 模型结果回到原解析与本地存储流程。请求含随机 installation_id 和固定 module，不携带项目方 Key。必要业务文本在内存临时转发，服务端不存正文；模型供应商会接收文本，不能将“本地保存”解释成离线推理。

统计由 background service worker 生成/持久化安装 UUID，串行处理初始化与入队，避免多个侧栏生成不同标识。模块执行 start + 首个终态共用 execution_id，只含 installation_id、execution_id、module、event、UTC date。后台队列最多 200 条/7 天，每分钟重试，业务不等待网络；超时或暂不可用保留，400/413 丢弃非法批次。关闭浏览器时暂停，超期和队列溢出可能漏计。

模块：JD 提取、手动添加、收藏/取消收藏、简历导入、岗位理解、简历理解、匹配、修改建议、开场白、Excel 导出。使用次数按真正执行统计，自动前置也计自身模块，重试不重复计模块使用；显式接入的 Deep Analysis / Resume Profile 缓存业务复用计成功，纯渲染与状态恢复不计数。下载成功指浏览器接受下载请求；重复 JD 去重属于保存操作成功。失效/取消任务不结算终态。AI 调用明细与模块成功分开，HTTP/模型完成并不保证结果解析或本地保存成功。

## 服务端数据与查询

保留 ai_calls、events，旧 events 增加 execution_id / module 和唯一索引。新增 installations（累计安装去重）、daily_installations（每日去重收据）、daily_metrics（聚合计数）。事件及汇总用 SQL 触发器同事务提交；重复/乱序事件只计一次，首个终态生效。

事件、AI 调用明细、每日去重收据保留 30 天，Cron 每日 03:00 UTC 清理；匿名累计安装记录及无安装标识的每日聚合持续保留。使用用户量是安装实例数，不是自然人数或下载数。清空扩展数据/重装、多设备可能重复计数。业务数据与原始错误不进入统计，不把 IP、UA、URL、文件名用于用户识别。客户端调试日志也不输出正文。

维护者查询：

```bash
npx wrangler d1 execute rolemi-metrics --local --file=sql/report.sql
```

没有公开统计查询 API。ai_calls 保留原有字符数、Token、耗时、模型、状态以核算成本。

## 初始额度与上线边界

截至 2026-09-26，相邻后端 `src/config.js` 的 `AI_QUOTA_DISABLED = true`，默认关闭调用次数限制；运行时环境变量可覆盖。设为 false 启用时，默认每安装 UTC 日 20 次、滚动一分钟 6 次、全局每日 200 次模型尝试；包含重试、前置任务、连接测试和失败。限额开启时，单条 INSERT 原子预占避免并发超额，D1 故障时不放行付费调用；调用后的统计更新失败不丢弃模型结果。无缓存完整流程通常 5 次，不要将次数额度解释成岗位数。

接口限制：AI 请求实际 UTF-8 字节数 100 KiB、文本 24,000 Unicode 码点，非流式，模块输出预算由服务端限制。用户看到额度不足或服务不可用提示，不回显上游原始错误。

第三方模型费用独立于基础设施；后端 `docs/deployment.md` 记录调用额度、成本公式和发布边界，不宣称已核验实时免费套餐。单安装标识和 CORS 无法防伪造，公开发布前需落实边缘防滥用、供应商金额上限、正式扩展 Origin、生产 Secret 和真实链路体验验收。发布后由维护者统一替换 BACKEND_URL 为 HTTPS 地址，普通用户不配置后端地址。

## 验证

插件运行 `npm test`；后端运行 `npm test` 和 `npm run test:worker`。后端两个测试命令等价；模拟模型验证密钥不外发、参数限制、额度并发、事件去重及回滚、数据保留，跨仓库测试导入插件真实客户端验证六类 AI 模块和十类统计模块。插件测试另覆盖缓存/重试和队列补发。旧库迁移需按实际表结构判断，不作为已完成的自动化覆盖。真实模型调用与正式发布不在本次自动化测试中。

## 接口与验收入口

完整字段、请求/响应示例、错误码、CORS 和重试语义见 [后端 API 文档](../../rolemi-backend-v2.7.0/docs/api.md)，启动与数据库升级见 [后端部署说明](../../rolemi-backend-v2.7.0/docs/deployment.md)。`/health` 不检查密钥、模型或数据库；真实 AI 验收需配置有效密钥并在服务设置中执行连接测试，再验证完整业务流程。当前代码配置的上游地址/模型不等于已经验证可用。

### 服务设置与请求策略

本页只维护托管网关边界。插件侧服务设置行为见 [实现契约](feature-spec.md#服务设置与请求策略)，配置存储与 API Key 生命周期见 [数据模型](data-model.md#服务设置与请求策略)，托管与自定义请求的选择规则见 [AI 流程](ai-pipeline.md#ai-请求路由)。

## 插件预算与托管上限差异（2026-09-26）

只读核对相邻后端 `src/config.js: OUTPUT_LIMITS` 和 `src/ai-gateway.js: handleAI`：网关通过 `Math.min(请求预算, 模块上限)` 限制实际发送值。插件配置不是托管模式最终上限。

| 模块 | 插件首次 / 自动重试预算 | 当前后端上限 | 托管实际首次 / 重试 |
| --- | --- | --- | --- |
| Deep Analysis | 4000 / 5000 | 5000 | 4000 / 5000 |
| Resume Profile | 4000 / 无 | 3000 | 3000 / 无 |
| Match | 4000 / 6000 | 4500 | 4000 / 4500 |
| Revision | 5000 / 8000 | 4000 | 4000 / 4000 |
| Greeting | 2500 / 2500 / 3120（精简/标准/详细，无业务自动重试） | 5000 | 同插件请求值 |
| Settings Test | 40 | 40 | 40 |

本次仅校正文档，不修改相邻后端参数。托管 Revision 重试目前不会提高实际输出上限，仅增加紧凑提示；需要调整时应同步前后端配置、契约与测试。自定义 API 不经过上述网关，仍受用户服务自身限制。
