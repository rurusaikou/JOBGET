# RoleMI 排障指南

## 1. 先判断问题在哪一层

```text
文件读不出文本             → PDF / DOCX Parser
文本有，但结构化项目丢失    → Resume Understanding
Profile 正常但 Match 不准   → Context / Match Prompt
请求没发出                 → Validation / Settings / dependency
请求发出但模型失败          → Feature Service / AI Client
结果写错岗位               → Request Registry / dependency key
```

开启 Debug：

```js
ROLEMI_DEBUG_API.enable()
```

## 2. 简历里明明有项目，但 `resume.projects` 是空的

v1.4.0 以后先不要只看本地字段 `resume.projects`。

本地 Parser 仍可能因为“科研项目”“产品工作”等非标准标题识别失败；它只是辅助结构。真正影响 Match 的是：

```text
rolemi.resume.profile.projects
```

如果 `profile.projects` 正确，即使本地 `projects=[]`，Match 仍能使用这些项目。

## 3. `resume.profile.projects` 也为空

检查：

1. Console 是否出现 `[RoleMI API timing] resume-profile`；
2. `resume.profile.sourceVersion` 是否等于当前 `resume.contentVersion`；
3. Resume Understanding response 是否真的包含 projects；
4. `profile-prompt.js` 是否仍要求识别科研项目、工作项目、平台建设、迁移等内容；
5. 是否因为 Raw Resume 超过 `resumeProfileChars: 4000` 而在请求前被拒绝。

不要优先继续给 `sections.js` 堆更多中文标题正则；那只能修某一种版式。

## 4. 为什么第一次上传简历比以前慢

因为现在多了一次 Resume Understanding AI 请求。但这个成本只按 **Resume Version** 支付一次。

上传成功后会先生成 Resume Profile；这个过程完成后页面仍等待用户点击“匹配”，不会自动开始完整 Match。

同一份简历之后匹配多个岗位，会直接复用缓存 Profile，不再重复做 Resume Understanding。

如果当前 Job 也还没有 Deep Analysis，Task Runner 会并行执行：

```text
Deep Analysis || Resume Understanding
```

而不是串行执行两次 Understanding。

## 5. 如何判断 Profile 是否被缓存

Application → Extension storage → `rolemi.resume`，查看：

```text
profile.resultId
profile.version
profile.promptVersion
profile.sourceVersion
```

重新上传相同内容时，Profile 应保留；简历内容变化后 Profile 应清空并重新生成。

## 6. 点击 Match 后卡在“理解简历”

检查：

```text
state.resumeState.understanding
state.resumeState.profileError
```

Resume Understanding 失败时，本地简历不会被删除。再次点击“匹配”会重新尝试生成 Profile。

## 7. Deep Analysis 很慢 / 经常失败

Deep Analysis 首次使用 `reasoning=low`；若输出未完整生成，Compact Retry 使用 `reasoning=none`，避免 reasoning 再次吃满输出预算。

```text
First Attempt：完整 JD + 4000 + low
Retry once：压缩 JD + 5000 + none + Compact Retry
```

只对 `max_output_tokens` / incomplete JSON 业务 Retry 一次。

查看：

```text
[RoleMI API timing] deep-analysis:first
[RoleMI API timing] deep-analysis:retry
```

可靠性统计：

```js
ROLEMI_DEBUG_API.stats()
```

## 8. Match / Revision 状态异常

合法状态只有：`idle / loading / success / error`。

正常存在：

```text
Match=success + Revision=loading
Match=success + Revision=error
```

Revision 失败不应把 Match 改成 error。

## 9. Match 是否还能回退原文

不能。

v2.7.0 正常 Match 必须有：

```text
有效 Job Profile
+
有效 Resume Profile
```

缺哪个，Task Runner 自动补哪个；补齐失败就停止 Match，而不是偷偷回退 Raw JD / Raw Resume。

## 10. 测试

```bash
npm test
```

测试应覆盖：手动 JD 校验 / 去重 / 持久化、网址预检与注入前拦截、Profile 缓存 / 失效、非标准项目结构化、Match 不发送 Raw Resume、Deep Analysis Retry、Task State、依赖版本和文档一致性。

## 11. 提取提示“不支持”或浏览器页面访问错误

自动提取只支持 BOSS 直聘、智联招聘和猎聘域名下的 HTTP/HTTPS 职位详情页。`chrome://extensions`、`edge://extensions`（包括 `edge:extensions`）、新标签页、本地文件和其他网站会在发送消息 / 注入脚本前被拦截，并提示使用“手动添加岗位”。支持的网站仍需进入具体职位详情页。

智联招聘支持搜索页 `/jobs`、城市职位分类页和带 `pageMode=recommend` 的推荐页。提取时先读取右侧当前选中的详情面板，不读取左侧岗位列表。若右侧详情尚在加载，请等待“职位描述”出现后重试；若页面显示安全验证，应先在网页完成验证，扩展不会绕过网站验证。

提取前必须同时读到岗位标题和岗位描述；任一缺失时提示确认两项已经显示，且不会保存部分数据。BOSS 正文兼容标准段落、嵌套段落和灰度 class；安全验证、登录失效、岗位暂停或下线会显示对应处理提示。若完成验证或重新登录后仍显示旧提示，刷新招聘页面并等待岗位描述出现后重试。

若仍显示 `Cannot access a chrome:// URL`，重新加载当前版本扩展并重新打开侧边栏，检查 `features/jobs/extract.js` 的网址预检是否生效。

## 12. 手动 JD 无法保存或保存后未自动分析

- 正文必填，不能全为空白，最多 2000 UTF-16 字符；其余四项选填。PDF / 图片来源需先复制文字，表单不提供文件解析或 OCR。
- 重复提示表示该手动 JD 的基本信息、岗位信息和正文经空白 / 大小写规范化后已存在；原岗位与收藏、分析结果保留。
- 保存失败会保留表单内容，可重试；取消或返回岗位池会清空内容。
- 保存成功返回岗位池，不自动进入详情或调用 AI；点击“查看详情”或“深度分析”继续。过短正文可能允许保存，但不满足深度分析至少 20 个非空白字符的要求。


## Resume Match 截断 / `max_output_tokens`

Resume Match 只消费 Job Profile + Resume Profile，默认 `reasoning=none`。首次预算 `4000`；若 Provider 返回 `status=incomplete` 且原因为 `max_output_tokens`，或最终 JSON 未完整生成，系统只自动 Compact Retry 一次：`reasoning=none + 6000`。Retry 不重新展开分析，只保留原判断维度并压缩字段表达，优先完成合法 JSON。

## v2.7.0 输入被拦截

- “当前内容不是招聘岗位”：核对保存正文，更换为招聘描述后重新分析；旧版岗位分析缓存需重新生成。
- “超过 4000 字上限”：清除当前文档，上传精简版简历。按提取后的文本计算，4000 字可继续，4001 字阻止简历理解、匹配、修改建议和开场白生成。
- “当前文档不是有效简历”：模型已拒绝该输入，重新打开仍保留判定。清除后上传候选人履历文档；同内容重传会复用拒绝结果。
- 文件提取成功仅表示文本可读，不代表输入是简历或可以匹配。网络错误仍可重试，不会被保存为非简历判定。

## 托管服务与统计排障

托管默认连接 `http://localhost:8787`，先按后端 README 配置 `.dev.vars` 并启动 rolemi-backend-v2.7.0，再重新加载扩展使新增后台 module/alarms 生效。默认使用 RoleMI 后端；用户保存自己的 Base URL、模型和 API Key 后，优先直连用户的 Responses API（仅支持 Responses API）。用户自定义模式下密钥丢失需重新填写；请求失败不自动改走托管。前端发布地址只由维护者在 config.js 修改。

- 503：检查 Worker 是否运行、项目方 Secret/AI_MODEL 是否配置、D1 是否初始化/升级；不打印密钥。
- 403：核对正式扩展 Origin 白名单；本地开发仅在 localhost/127.0.0.1 开启开发来源规则。
- 429：每分钟 6 次、每天每安装 20 次、全局 200 次；前置步骤、重试、连接测试同样占额度。
- 统计暂未出现：后台队列每分钟补发，可查看 `rolemi.usageQueue` 的最小元数据；网络失败不影响功能。查询本地/远程 D1 要匹配运行环境，默认本地库。
- `no such column execution_id`：原两表库尚未执行一次性 `sql/metrics-v2.sql`；不要重复执行 ALTER，也不要将新 schema 当迁移。
- 模块成功数和模型成功数不同：缓存不调用模型，模型完成后解析/存储仍可能失败，查看 events 汇总与 ai_calls 各自口径。

Debug 不再输出请求/响应正文及原始错误；请使用固定状态、时长、Token 元数据定位问题。完整步骤见 [后端接入说明](backend.md)。

后端 `/health` 不检查模型或 D1；新库必须依次执行 `sql/schema.sql`、`sql/event-aggregates.sql`。已有 v2.5 库补装后者即可。没有真实密钥时无法验收 AI；完整错误码见 [后端接口说明](../../rolemi-backend-v2.7.0/docs/api.md)。

## 托管预算与埋点排查

插件调高输出预算后仍截断时，检查后端 `OUTPUT_LIMITS`。网关取请求预算与模块上限的较小值，当前差异见 [backend.md](backend.md)。Debug 的请求预算不能证明上游采用了同一数值。

使用次数与模型调用数不同：仅 Deep Analysis / Resume Profile 的显式缓存路径计成功；过期任务可能只留下 start。字段、队列丢弃、触发位置和复验步骤见 [metrics.md](metrics.md)。
