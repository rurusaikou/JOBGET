# RoleMI 文档导航

建议先理解产品的数据流，再读实现细节。

| 想知道什么 | 阅读文档 |
|---|---|
| RoleMI 解决什么问题、为什么要先做 Profile | `product.md` |
| 各版本新增或调整了什么 | `CHANGELOG.md` |
| App / Features / Shared 怎么分层 | `architecture.md` |
| Job Profile、Resume Profile、Match 分别怎么跑 | `ai-pipeline.md` |
| Profile 如何保存、复用和失效 | `data-model.md` |
| 第一次读源码从哪里开始 | `code-guide.md` |
| 项目经历没提取、请求慢、状态异常怎么查 | `troubleshooting.md` |
| 三个招聘网站的岗位提取测试结果 | `extraction-test-2026-10-03.md` |
| 手动添加岗位、网址支持范围和录入限制 | `feature-spec.md` / `troubleshooting.md` |
| 精确版本、reasoning、token、限制 | `feature-spec.md` |
| 埋点位置、字段、触发条件、缓存口径与补发验收 | `metrics.md` |
| 代码与文档核对范围、修正项和验证结果 | `consistency-audit.md` |
| 最近一次代码审查问题与解决方法 | `code-review-2026-10-02.md` |
| 前端可用性、异常、互斥与异步专项测试结果 | `frontend-test-2026-10-03.md` |
| 托管后端如何接入、额度/错误怎么处理 | `backend.md` |
| 后续功能与首次使用门槛优化 | `todo.md` |

## 推荐阅读路线

### 只想理解产品

```text
README.md → product.md → ai-pipeline.md
```

### 想理解 Resume Understanding

```text
product.md
  ↓
ai-pipeline.md §4
  ↓
architecture.md §4
  ↓
features/resume/profile-prompt.js
  ↓
features/resume/profile-service.js
  ↓
shared/context/builders.js
```

### 想读完整源码

```text
architecture.md → code-guide.md → app/task-runner.js → features/* → shared/*
```

## 文档维护原则

1. README 面向第一次看到项目的人，不堆内部常量。
2. `feature-spec.md` 记录必须与代码一致的精确实现值。
3. 修改用户功能、交互、数据结构、AI 流程或项目版本时，必须同步更新 `CHANGELOG.md`；未发布变更记录在顶部“待发布”章节。
4. 修改 JD 收集流程、网址支持范围、录入上限、去重规则、Profile schema、Prompt、reasoning、token、Context、缓存、依赖或状态机时，必须同步更新相关文档。
5. 测试只能发现部分不一致；重大架构变化仍需人工复核语义。

## 前后端联调

- `backend.md`：扩展如何调用 RoleMI 托管后端、错误映射与隐私边界。
- `metrics.md`：前端 `startUsage / trackUsage / cachedUsage` 与各模块埋点位置。
- 后端 `docs/README.md`：后端文档总入口；额度配置见后端 `docs/configuration.md`。
- 后端 `docs/api.md`：`/api/ai`、`/api/events` 完整接口契约。
- 后端 `docs/verification.md`：联调与测试检查记录。
