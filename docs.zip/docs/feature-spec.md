# RoleMI v2.7.0 实现契约

当前版本：v2.7.0

## 文档用途

这是“代码事实表”。README / product.md 讲产品；architecture.md 讲分层；ai-pipeline.md 讲 AI 数据流；这里记录必须和代码一致的版本、依赖、预算与边界。

## 系统概览

- 架构：`app / features / shared`。
- Popup 入口：`src/popup.js`。
- AI Workflow：`src/app/task-runner.js`。
- 两个 Understanding 结果：Deep Analysis → Job Profile；Resume Understanding → Resume Profile。
- Match 只比较有效的 Job Profile × Resume Profile。
- Match 与 Revision 是独立 Feature、独立 request ticket、独立 UI Task State。

## 视觉原则

- 保留 RoleMI 原始品牌图标，不替换或重绘 Logo。
- 蓝色作为主要操作色，青色与紫色仅用于少量状态、图标和强调点缀。
- 页面以白色背景、浅边框和低装饰卡片为主；常规内容卡不使用投影，避免信息层级过重。
- 顶部 RoleMI 图标与文字组成可点击品牌入口，点击后进入独立欢迎首页并滚动到顶部；欢迎首页复用品牌引导、提取和手动添加入口，顶部“岗位池 / 收藏”均不选中。已有岗位、搜索条件和进行中任务继续保留；点击“岗位池”可返回管理列表，品牌入口不承担重置功能。
- 优先通过留白、字号和文字层级组织信息，不增加无功能的装饰元素。
- 空岗位欢迎卡在右侧放大裁切 RoleMI 原始图标作为低透明度品牌水印，并用蓝、青、紫三个独立柔光节点对应“看懂岗位、看清差距、知道怎么投”。节点不使用连线、箭头或编号，避免流程图感；整个背景容器设置为 `aria-hidden`，不得遮挡文字或形成操作暗示。
- 按钮使用固定语义而非按页面自由配色：蓝色实心表示当前主操作；蓝色描边表示次级、查看、取消、测试或重新执行；蓝色文字表示低优先级跳转；红色描边表示危险操作入口；红色实心仅用于确认执行删除或清空。禁用状态统一降灰，加载状态保留原层级颜色并锁定重复提交。
- 常规主按钮、次级按钮和危险按钮最小高度为 36px；紧凑卡片操作可使用 30–32px，但同一操作组必须共用相同规格。
- 保存、清空、上传等异步入口必须锁定重复提交，并在成功或失败后恢复可用状态；失败需提供用户可见反馈。伪装为按钮的文件上传入口不得通过 `display: none` 移除原生 input 的键盘可访问性。
- 复制岗位描述和沟通草稿必须读取浏览器复制结果；成功时显示已复制，返回 false 或抛出权限异常时提示手动复制，并清理临时 DOM。

## 项目结构

- `src/app/`：State、Runtime、Task Runner、Controllers。
- `src/features/jobs/`：提取、手动添加、去重、列表与导出。
- `src/features/jd-analysis/`：Job Understanding。
- `src/features/resume/`：PDF / DOCX 本地解析、Resume Understanding、Profile 缓存。
- `src/features/resume-match/`：人岗匹配。
- `src/features/resume-revision/`：独立修改建议请求。
- `src/features/greeting/`：求职开场白。
- `src/shared/`：AI、Context、Storage、UI、Config。

## 数据与存储

- Job / Resume 使用稳定 ID + contentVersion。
- Resume Profile 是派生缓存，不参与 Resume contentVersion。
- Profile 有 `resultId / version / promptVersion / sourceVersion / updatedAt / usage`。
- 同 Resume contentVersion 重传可复用 Profile；内容变化自动失效。
- 默认使用 RoleMI 后端；`mode` 区分托管与自定义，`provider` 仅表示实际供应商，`apiType` 当前固定为 `responses`。用户保存自己的 Base URL、模型和 API Key 后，优先直连用户的 Responses API。Chat Completions 地址会被拒绝，项目方托管 Key 仅在服务端。
- Job、Resume 与 Resume Profile 保存于浏览器 local storage。

## Context 模块

`CONTEXT_VERSION = 1`  
`SUMMARY_VERSION = 3`  
`RESUME_PROFILE_VERSION = 2`

Prompt 版本：`JD 分析 5`、`Resume Profile 3`、`简历匹配 9`、`开场白 7`。

固定常量：

- `contextChars: 12000`
- `resumeProfileChars: 4000`
- `deepAnalysisRetryDescriptionChars: 3200`

### 各任务使用的信息

- **JD Analysis**：Raw JD → Job Profile。
- **Resume Understanding**：Raw Resume → Resume Profile；上传成功后立即前置生成并缓存，同一 Resume Version 只生成一次。
- **Resume Match**：强依赖有效 Job Profile + Resume Profile。Match 不回退 JD 原文，也不回退 Resume 原文。
- **Resume Revision**：Target Job（仅 `title`）+ Resume Profile + Match Result（直接匹配 / 可迁移能力 / 关键缺口）；不重新发送完整 JD / Resume 原文。Task Runner 传入当前 Match 的岗位快照，首次与重试都将 `job` 作为 Prompt 第三个参数，`{ compact }` 作为第四个参数，缺失标题回退为“未提供”。
- **Greeting**：岗位本质 + 核心要求 + 按内容密度筛选的直接匹配 / 可迁移证据 + 沟通风格（tone）/内容长度档位；不发送 JD 或简历原文。

### Resume Profile 与本地 Parser 的关系

本地 Parser 负责读文件、规范化文本和生成辅助结构；它可能无法正确识别“科研项目”“产品工作”等非标准章节。Match 不直接依赖本地 `resume.projects`。

Resume Understanding 读取完整 Raw Resume，语义识别：education / workExperience / projects / skills / certifications / languages / otherEvidence。`projects` 必须允许工作项目、科研项目、课题、平台建设、迁移等不同标题形式。

## 结果复用与失效

### 依赖关系

```mermaid
graph LR
  J[Job Version] --> A[Job Profile / Deep Analysis]
  R[Resume Version] --> P[Resume Profile]
  A --> M[Resume Match]
  P --> M
  M --> V[Resume Revision]
  M --> G[Greeting]
  T[Tone / Length Tier] --> G
```

Deep Analysis 与 Resume Understanding 都是 Match 的必需数据前置，但不是必需用户操作。正常上传后会先调用 `runResumeUnderstanding()` 预热缓存，且**不自动启动 Match**；用户在“匹配”页点击“开始分析”后，`runResumePipeline()` 会自动补齐仍缺失的依赖，两者都缺失时并行准备。

简历上传区仅提供 PDF / DOCX 文件上传，不再提供“使用示例”入口。岗位或简历理解中的提示仅说明当前处理步骤，不承诺完成后自动匹配；尚未发起匹配时，处理完成后显示“等待分析”，引导用户点击右上角“开始分析”。已经发起的匹配流程仍会在依赖准备完成后继续执行。

Match dependency key 包含 `analysisResultId`、`resumeProfileId`、`resumeProfileVersion`。

### 防止旧请求覆盖新数据

```mermaid
graph TD
  S[Start Request] --> K[Freeze Inputs + Dependency Key]
  K --> API[Call Model]
  API --> C{Ticket still current?}
  C -- yes --> W[Write Result]
  C -- no --> D[Discard stale result]
```

Revision 额外绑定当前 Match `resultId`。Resume Profile 保存前也校验当前 Resume id / contentVersion，避免旧上传结果覆盖新简历。

## 功能实现

### 顶部菜单、使用帮助与反馈

- 主页面右上角统一使用三点菜单，菜单项为服务设置、使用帮助和反馈建议；服务设置仍受 `API_SETTINGS_ENABLED` 控制，帮助与反馈始终可用。菜单打开后聚焦首项，支持上下方向键、Home、End 和 Escape，关闭后 Escape 将焦点还给菜单按钮。
- 岗位池与收藏页均通过覆盖整卡的独立详情按钮打开原始岗位详情；该按钮可用 Tab 聚焦并以 Enter / Space 激活，不在含星标和分析按钮的卡片容器上声明 link 角色。星标固定在卡片右上角并与标题行对齐，星标和底部分析入口独立响应。底部不重复提供详情入口：未分析时显示“尚未分析 / 分析岗位”并启动首次分析，存在可复用分析时显示“已有分析结果 / 查看分析”。分析入口使用至少 88×32px 的带边框按钮及独立悬停状态，减少误触整卡详情区域。
- 使用帮助按“开始使用、分析岗位、准备投递、管理岗位”分成四组，提供提取当前岗位、手动添加岗位、岗位分析、简历匹配、修改建议、沟通草稿、收藏和导出收藏八个抽拉项。点击后在当前页面展开功能含义与操作步骤，各条目独立控制并允许同时展开多个，不进入独立详情页。
- 反馈保留“功能异常、分析不准、使用建议、其他”四种 2×2 按钮式单选类型，正文最多 500 字且必填；提交按钮在正文为空时禁用。
- 反馈可从本地岗位池选择一个相关岗位，首项固定为“不关联岗位”，展示格式为“岗位名称｜公司名称”。关联数据说明以灰色辅助文案展示在字段标题与下拉框之间；选择相关岗位后，会提交该岗位 ID、JD 及已生成的工作流结果快照，不提交简历原文或附件。
- 反馈快照保持浏览器存储中的派生结果层级：岗位分析提交完整 `deepAnalysis`；匹配提交带依赖元数据的 `resumeMatch` 外层对象，但从其 `result` 中拆出修改建议字段；修改建议单独提交 `revisions / revisionError / revisionCompleted / revisionUsage`；沟通结果提交完整 `greeting` 外层对象。
- 插件以 JSON 向托管后端 `POST /api/feedback`；选择相关岗位时附带该岗位 JD、岗位分析、简历匹配、修改建议和沟通结果（仅已生成部分），不提交简历原文。请求失败时保留表单并显示错误。
- 服务设置显示当前默认或自定义服务状态，保留 API 地址、模型名称、API Key、测试连接和保存机制；提供独立的“恢复默认服务”入口，一次清除自定义配置与会话密钥并切回 RoleMI 默认服务。

### 岗位分析状态卡响应式布局

- 状态卡使用“状态信息 + 操作按钮”的两列网格；标题与时间靠左，“重新分析”按钮在所有侧栏宽度下固定靠右。加载态隐藏操作按钮并保持内容靠左。
- 分析进行中不显示按钮，标题与动态主题整体居中；宽度变化不改变任务状态或轮播逻辑。

### 岗位获取与手动添加

- 主页面同时提供“提取当前岗位”和“手动添加岗位”，图标使用 `currentColor` 的 SVG，统一为 16px、2px 线宽。
- 岗位池为空时隐藏常规“岗位获取”工具区，显示独立欢迎页：浅蓝圆角卡片依次展示“Hi 👋”“今天在看什么机会？”和“先看懂岗位，再决定怎么投。”；下方为整行蓝色“提取当前岗位”、无边框文字型“手动添加岗位”、支持平台说明，以及横向排列的“看懂岗位、看清差距、知道怎么投”三项能力提示。提取期间或失败时，支持平台说明位置同步显示当前结果；从欢迎首页提取成功或发现重复岗位后，仅在用户仍停留于该首页时进入岗位池。新增岗位会清空旧搜索并滚动到可见区域；清空岗位池后恢复默认支持平台说明，不保留此前的提取中状态。
- 空岗位欢迎页不展示搜索、计数、岗位列表及“导出全部岗位 / 清空岗位池”。添加岗位后隐藏欢迎页，恢复常规岗位获取操作、搜索和岗位池管理界面。
- 岗位计数不占用提取操作行；有岗位时显示在搜索框右侧，与搜索框等高。搜索行随空岗位状态隐藏，因此空岗位时不单独显示零计数。
- 岗位池存在岗位时，“岗位获取”、提取/手动添加按钮和搜索/计数合并为一个吸顶操作区；岗位列表在其下独立滚动，操作区固定在顶部标签下方，以白色背景和细分隔线区分，不使用阴影；第一张岗位卡与操作区保留 8px 间隙。空岗位欢迎页不显示该吸顶区。
- 收藏页导出按钮命名为“导出收藏”，只导出已收藏岗位。清空岗位池必须先显示确认窗口；用户取消时不修改数据，确认后进入“清空中…”锁定态，避免重复提交。
- 清空确认使用页面内模态框，标题为“清空全部岗位？”，说明岗位池、收藏及关联分析结果会删除，但简历保留；操作为“取消 / 清空岗位”。清空处理中禁用取消并阻止 Escape 关闭；失败时保持窗口并在窗口内显示错误，成功后关闭。
- 所有子页面左上角返回入口统一显示“返回”，内部仍按来源页面返回。空岗位欢迎页不选中顶部“岗位池”标签；存在岗位并进入岗位池管理视图时才显示选中态。
- 岗位池卡片底部左侧显示分析状态：无当前有效分析时为“尚未分析”，右侧操作为“分析岗位”；存在可复用分析时为“已有分析结果”，右侧操作为“查看分析”。两种操作均进入分析页，仅前者启动新分析。
- 按钮统一具备默认、悬停、按下、禁用和处理中视觉状态；首页与岗位池的提取入口共享同一处理中锁，任一入口发起后两处同时禁用并显示“提取中…”。异步导出、清空和表单保存期间同样禁用触发按钮，防止重复请求。确认清空会使此前启动且尚未完成的提取失效，迟到结果不得写回岗位池或改变当前页面。岗位卡片与详情页星标使用颜色、缩放和按压过渡，收藏写入期间忽略重复点击。
- 自动提取仅允许 HTTP/HTTPS 协议，主机名须为 `zhipin.com`、`zhaopin.com`、`liepin.com` 或其子域名。`extract.js` 在消息发送和脚本注入前校验 `tab.pendingUrl || tab.url`；通过后由 `content.js` 继续检查职位详情内容。
- 智联招聘兼容 `/jobs` 搜索入口、`/{城市}/{职位分类}/` 分类入口及带 `pageMode=recommend` 的推荐入口。搜索和推荐页面必须从 `.job-split-layout__right .job-detail-panel` 读取当前右侧岗位；直接详情页面回退到 `.job-detail-panel`。新版字段使用 `job-detail-summary-*` / `job-description__content`，同时保留旧版 `summary-planes-*` / `describtion-card__detail-content` 回退。
- 网页岗位仅在标题和岗位描述同时非空时提取成功。只有一项出现视为详情仍在加载，提示等待完整后重试，不写入岗位池。
- 内容脚本在通用详情校验前识别明确的安全验证、岗位暂停/下线和登录失效文案，分别提示完成验证、更换有效岗位或重新登录。普通导航中的“登录/注册”不作为登录失效依据。
- BOSS 岗位描述优先读取标准 `.job-detail-body > p.desc`，兼容增加包装层、正文 class 调整及灰度页面；专用选择器均未命中时，只在当前详情的 `.job-detail-body p` 中选择不少于 20 字的最长正文段落，不跨到左侧列表。
- `chrome://extensions`、`edge://extensions`、`edge:extensions`、新标签页、本地文件及其他网站均不支持自动提取，显示中文提示并引导“手动添加岗位”。
- 手动表单优先展示岗位描述，标注“必填 · 最多 2000 字”；职位名称、公司 / 地点、经验 / 学历、薪资四项收进默认折叠的“补充信息 · 选填”，展开后采用纵向整行输入框。岗位描述全空白无效，内容为空时“添加岗位”按钮禁用，输入有效内容后启用。
- `MANUAL_JD_MAX_LENGTH = 2000`；表单 `maxlength` 和业务校验均为 2000，不展示实时字数计数。按输入字符串的 UTF-16 长度计数，包含首尾空白；保存时去除首尾空白。
- 仅接收粘贴文本；提到 PDF、图片文字表示粘贴从这些来源复制的文字，不提供 JD 文件上传或 OCR。
- 公司 / 地点整体写入 `company`，岗位信息整体写入 `experience`，不自动拆分 `location` / `education`，也不调用 AI 补全选填项。
- 保存期间禁用表单和返回按钮，避免重复提交。成功后清空表单与搜索，返回岗位池并选中、滚动到新增岗位，不自动打开详情或启动分析。
- 重复或保存失败时留在表单，显示提示并保留输入；“取消”和“返回”清空输入并折叠补充信息。切换设置再返回会保留尚未提交的表单；关闭侧边栏后不保证草稿保留。
- 手动 JD 复用 `updateJobs → appendUniqueJob → setJobs` 写入队列，可继续搜索、收藏、查看详情、分析和导出。
- 保存与分析的校验不同：手动保存只要求正文非空且不超过 2000；Deep Analysis 还要求去除空白后至少 20 字符、正文不超过 5000 字符且不是无效占位文本。

### Deep Analysis 等待态

Deep Analysis 保持现有任务流与 reasoning 配置不变。同一岗位、同一内容版本存在进行中请求时，详情页或岗位池再次触发均直接复用进行中状态，不重复调用模型。请求进行中，状态卡内容整体靠左，采用上下两层布局：第一行的加载圆圈与 `正在深度分析` 文字垂直居中，第二行从主文字起点对齐并显示动态分析主题；动态主题每 3.5 秒轮播一次：`正在识别核心要求…` → `正在区分必要条件与加分项…` → `正在分析隐含要求…` → `正在整理理想候选人画像…` → `正在整理分析结果…`。最后一条保持到请求结束。

这些文案只用于降低长推理的感知等待时间，不代表模型真实执行阶段或完成比例，因此不显示步骤编号、完成勾选或百分比。请求完成、失败、切换岗位或退出 loading 状态时停止轮播；状态文本使用 `aria-live="polite"` 提供非打断式辅助技术提示。

状态卡的标题、说明和加载内容始终左对齐。完成或错误状态采用左右两列布局：标题与说明位于左侧，“重新分析”按钮按内容宽度固定在右侧；窄侧栏也不把按钮移到底部左侧。等待状态隐藏操作按钮，内容容器拉满可用宽度，加载标题行从卡片左侧开始。

### Resume 与匹配

简历匹配页始终保留紧凑的简历状态卡，不显示额外“简历”标题。布局与深度分析状态卡一致：左侧显示文件名，右侧固定显示“上传简历 / 更换简历”；该入口与匹配结论卡的“重新分析”共用同一紧凑次级按钮规格，包括 30px 高度、最小宽度、内边距、圆角、边框和交互状态。仅在解析中、理解中、失败或尚未完成理解时显示第二行状态，理解成功后隐藏冗余说明。信息卡与下方匹配内容保持 12px 间距，且不因进入匹配结果而隐藏。

匹配结果仅展示匹配等级、判断依据及直接匹配 / 可迁移能力 / 关键缺口，不将等级映射为百分比，不显示评分进度条。处理中保留状态文字、按钮忙碌状态及动态加载进度条。加载条仅表示任务进行中，不代表完成百分比或匹配分数；理解岗位、理解简历和匹配分析时显示（含保留旧结果的重新分析），等待、完成或处理停止后隐藏。

匹配概览隐藏时（等待、准备、分析中或无结果的错误状态），结论区切换为单列并使用卡片完整可用宽度，不保留空白的概览列；较窄窗口仍允许文字自然换行。结果生成后保留结论与匹配概览的响应式布局。

修改建议的“优先补强”仅从实际建议中提取；无有效标题、生成中或失败时隐藏该区域。生成成功但建议为空时显示“暂无修改建议。”；尚未生成、生成中和失败分别展示对应状态，不以固定建议兜底。

匹配详情及修改建议卡片对连续英文、箭头连接的流程（如 `Requirement→Priority→Evidence→Match→Boundary→Decision`）和长链接启用按可用宽度换行。匹配字段保持双栏且内容不跨列；修改建议的优先补强、标题、理由及展开正文完整换行，网格和内部文本允许收缩，不以裁切或隐藏溢出处理长文本。

Resume 运行时：

```text
parsing        = 本地 PDF / DOCX 文本提取
understanding  = AI Resume Profile 生成
profileError   = Profile 生成失败信息
```

Match / Revision 使用 `idle / loading / success / error` 四态。

- Match 成功立即持久化。
- Revision 随后独立运行。
- Revision error 不改变 Match success。
- Revision 每条建议包含 `category / summary / original / rewrite / reason`；`category` 在修改建议列表中以标签展示。
- Revision 使用 Suggestion Gate：候选建议至少满足事实表达增益、岗位关联增益、证据结构增益或有相关线索的真实信息缺口之一。最后一种只能生成“经历补充”，`rewrite` 为空，`reason` 说明待确认信息；明确缺失且无相关线索的问题不进入 Revision。
- 不输出仅同义改写、堆关键词、追加能力总结、无实质增益、依赖不存在事实或重复解决同一问题的建议。按岗位匹配证明力的提升降序排列，不设置固定条数，不强求数量；首次输出受 `5000` tokens 预算约束，Compact Retry 为 `8000` tokens。
- 所有改写可追溯到 Resume Profile；禁止将参与升级为主导、技术实现升级为产品负责、局部功能升级为 0→1 产品，或把可迁移能力改写成直接经验；禁止把候选人的业务对象、流程或场景替换为 JD 目标业务，或仅凭 JD 术语重新定义候选人的经历。
- Revision Schema 字段长度上限：`summary=80`、`original=180`、`rewrite=220`、`reason=160`；`original` 只引用最相关原文，`reason` 说明原文问题及具体增益或待确认信息。
- 建议卡片收起时保留标题、类别和摘要说明，移除额外的原内容 / 改写预览；摘要按 `reason → rewrite → summary → 补充提示` 回退。展开后展示原内容（存在时）、修改依据 / 待补充信息和改写（存在时）。
- Greeting 只要求 Match 当前有效，不要求 Revision success。

## API 调用

Reasoning：JD 深度分析首次 = `low`，Deep Analysis Compact Retry = `none`，Resume Profile = `none`，Resume Match = `none`，Resume Revision 首次 = `none`、Compact Retry = `none`，Greeting = `none`。

Token（插件请求预算；托管最终值另受后端模块上限限制，见 [预算差异表](backend.md#插件预算与托管上限差异2026-09-26)）：

- Deep Analysis 第一次预算为 `4000`；Retry 预算为 `5000`。
- Resume Profile = `4000`。
- Match 第一次 = `4000`；Compact Retry = `6000`。
- Revision 首次 = `5000`；Compact Retry = `8000`。
- Greeting 输出预算由内容长度档位的内部选择值计算（当前至少 `2500` tokens；详细档会适度上调）；该预算仅用于保证模型输出完整，不是页面字符上限。
- Settings Test = `40`。

Resume Understanding 输入上限：`resumeProfileChars: 4000`。它不静默截断简历原文。

Deep Analysis 仅在 `max_output_tokens` / incomplete JSON 时自动 Retry 一次；首次使用 `low` reasoning 与字段级表达预算。Retry 使用 `deepAnalysisRetryDescriptionChars: 3200` 的紧凑 JD、`none` reasoning 和 Compact Retry 指令，优先完成完整 JSON。

Resume Match 只消费 Job Profile + Resume Profile，默认使用 `reasoning=none`，避免 reasoning 占满最终 JSON 的输出预算。若因 `max_output_tokens` 或 incomplete JSON 未完成，只自动 Compact Retry 一次；Retry 仍使用 `none`，预算提升到 `6000`，并要求不新增分析维度、优先完成紧凑 JSON。

Resume Revision 在 `max_output_tokens`、JSON 无法解析或空输出时只自动 Compact Retry 一次：切换为 `none`，预算提高到 `8000`，沿用相同输入与 Schema，压缩表达并保留事实边界。合法空建议列表不重试；网络、API 错误及其他 incomplete 原因不触发此兜底；再次失败直接上报，保留 Match success。

Provider 不支持 reasoning 时，AI Client 可去参兼容重试；这与 Deep Analysis 业务 Retry 不同。

## 导出、隐私与调试

- Resume Profile 不保存姓名、手机号、邮箱。
- Raw Resume 仅用于 Resume Understanding；正常 Match 不发送 Raw Resume。
- Greeting 不发送 JD / Resume 原文。
- Debug 默认关闭。
- `ROLEMI_DEBUG_API.enable()` 开启日志。
- Resume Understanding timing label：`resume-profile`。
- `ROLEMI_DEBUG_API.stats()` 查看 Deep Analysis `firstAttempt / retry / finalFailure`。

## 已知限制与后续方向

- Resume Understanding 依赖所选 Provider 的结构化 JSON 能力。
- 扫描版 PDF 若本地无法提取文本，当前不做 OCR。
- 超过 4000 字符的 Resume 当前拒绝 Profile 请求，不静默裁剪。
- Profile 提取质量仍应通过真实简历样本持续评测，重点观察项目召回和事实幻觉率。
- 性能优化应优先比较首次 Resume Understanding 耗时与后续多岗位 Match 复用收益。

## 代码可读性约定

注释解释模块边界、版本失效、缓存与异步写回原因；不为简单 DOM 操作逐行注释。代码修改必须同步更新相关文档。

## 校验记录

`tests/manual-job.test.mjs` 校验手动正文边界、去重与持久化；`tests/extract-url.test.mjs` 校验协议 / 域名范围和注入前拦截。

`tests/docs-consistency.test.mjs` 校验手动 JD 上限与表单、文档的一致性，以及版本、Prompt / Profile 版本、Reasoning、token/input 限制、Raw JD / Raw Resume Match 边界和隐私关键事实。

## JD 分析 Prompt v5 与结构化隐形要求

`features/jd-analysis/prompt.js` 定义分析目标、七步分析顺序、判断规则与字段级表达预算；system 消息说明招聘材料中的指令不能执行，user 消息包含分析规则和岗位字段。Compact Retry 会追加“直接完成结构化结果、优先保证 JSON 完整、显著压缩表达”的指令。

顶层先输出 `isJobDescription / nonJdReason`，分析字段为 `essence / coreRequirements / hiddenRequirements / idealCandidate`。除隐形要求外均为字符串数组；`hiddenRequirements` 为 `{ requirement: string, basis: string }[]`，无充分依据时为空数组。Schema 允许四个分析数组为空以表示非 JD；有效 JD 的结果校验要求岗位本质、核心要求和理想候选人非空。Schema 上限分别为 2、5、5、1 条。

- 存储、解析和 Markdown 兜底统一规范化隐形要求为对象，页面分别展示要求与依据并转义 HTML。
- 旧字符串“要求｜依据”按第一个分隔符拆分，其余分隔符留在依据中；没有分隔符时依据为空，不补造事实。无法恢复的 `[object Object]` 记录丢弃。
- 文本及 Excel 导出格式为“要求｜依据：依据内容”，不直接 stringify 对象。
- Job Summary 的 `inferredRequirements` 同样保留对象数组。Match 结合 requirement 与 basis 理解推断，basis 不是候选人经历证据；推断不作为硬性门槛，缺少依据时不据此判定缺口。
- `SUMMARY_VERSION = 3`、Resume Profile Prompt 3、JD 分析 Prompt 5、Match Prompt 9、Greeting Prompt 7，使旧分析、摘要和下游匹配 / 修改建议 / 开场白缓存失效；原始 JD 和简历保留，后续触发任务时重新生成。

内部分析顺序：识别明确要求 → 合并相关项 → 判断重要性 → 筛选核心要求 → 推断隐形要求 → 抽象岗位本质 → 形成画像。成功标准是关键要求无明显遗漏、核心要求有重要性依据、岗位本质解释问题与价值、推断可由 JD 支持、画像与前文一致、信息密度高且不重复。


## Greeting v2.7.0 交互契约

- 底部状态栏初始为空；无文字时隐藏且不占布局空间，仅在有复制反馈、生成错误或选项调整提示时显示，清空文字后自动隐藏。

- 内容长度 UI 仅展示“精简 / 标准 / 详细”，用于表达内容密度：精简只说最核心信息；标准包含核心身份、主要匹配点与沟通意愿；详细提供更多岗位相关证据和动机。
- Greeting 只使用 Match Top Evidence：精简最多 1 条、标准最多 2 条、详细最多 3 条，不发送完整 Resume Profile；模型返回内容完整展示，前端不做字符截断或字数计数。
- 生成结果为可编辑 textarea，不显示字数、不设置字符上限，也不对模型结果做前端截断；复制当前编辑值，有手动修改时重新生成需确认覆盖。

## v2.7.0 异常输入处理

| 场景 | 检查时机 | 页面与流程 |
|---|---|---|
| 保存非 JD 内容 | 深度分析输出 `isJobDescription=false` | 展示 `nonJdReason`，隐藏四项岗位分析卡片，禁用匹配、修改建议、沟通入口，拦截下游任务 |
| 简历超过 4000 字 | 本地提取文本后、任何后续分析前 | 展示实际字数与上限，保留本地文档供清除，不发起简历理解或下游请求；上传或解析错误写入运行时状态，常规刷新不得用默认文案覆盖 |
| 上传非简历文档 | Resume Understanding 返回 `validResume=false` | 按内容版本保存拒绝结果，显示“无法匹配”，禁用匹配与下游生成，提示清除后上传简历 |

字数按规范化后的 `rawText.trim().length`（UTF-16 字符数）计算，恰好 4000 字允许继续；不静默裁剪。恢复旧文档时同样执行长度检查，即使已有 Profile 也不能绕过上限。

非简历判定随当前内容保留，重新打开或同内容重传不会重复调用模型；清除或更换内容后重新判定。网络、输出格式等临时失败不作为非简历判定，仍允许重试。

JD 分析 Prompt v5 的输入判定字段仅位于顶层；隐形要求子对象只有 `requirement`、`basis`。旧版分析缓存失效，需重新分析。

## 托管 AI 与匿名使用统计

默认使用 RoleMI 后端；用户保存自己的 Base URL、模型和 API Key 后，优先直连用户的 Responses API（仅支持 Responses API）。托管请求统一走本地 Worker `/api/ai`，由服务端确定模型和密钥。后台仅发送匿名安装/执行 UUID、模块、事件及日期，记录使用/成功/失败；模型重试只增加 ai_calls，不重复计模块使用。显式接入的 Deep Analysis / Resume Profile 缓存业务复用计成功，纯渲染不计数。详见 [后端接入说明](backend.md)。

导出计浏览器接受下载，收藏及取消收藏都计 favorite，重复 JD 成功去重计保存成功；简历导入与 AI 简历理解分别统计。统计异常不阻断业务；默认每安装每日 20 次、每分钟 6 次、全局每日 200 次模型尝试。30 天明细清理与永久匿名聚合口径、生产发布边界见后端文档。

### 服务设置与请求策略

默认使用 RoleMI 后端；用户保存自己的 API 地址、模型名称和 API Key 后，优先直连用户的 Responses API（仅支持 Responses API）。服务设置显示当前服务状态，可通过“恢复默认服务”清除三个自定义字段并立即切回 RoleMI；三个字段全部清空后保存也可恢复。部分填写时拒绝保存。测试、保存和恢复默认共享互斥锁，任一操作期间禁用全部设置字段及操作按钮。local 与 session 跨区域写入失败时尽力恢复操作前配置。自定义请求失败或会话密钥丢失时提示错误，不自动回退托管。非敏感配置保存在 local，API Key 仅保存在 session。`API_SETTINGS_ENABLED` 当前为 `true`，仅控制入口显示，不影响已保存配置的优先级。

### 修改建议等待与重试

生成期间展示轮播主题但不伪造进度；减少动态效果偏好下改为静态展示。失败时只提供一处“重新生成修改意见”入口，不暴露模型原始错误。按钮需锁定重复提交，过期结果不得覆盖当前岗位或简历。轮播节奏、任务复用及重试边界见 [AI 流程](ai-pipeline.md#修改建议等待与重试)。
