# RoleMI 埋点说明（v2.7.0）

核对日期：2026-09-26。以下以本仓库调用点为准，描述当前实现；不表示已部署公网或已验证生产数据。

## 1. 统计范围与调用链

当前记录 10 个业务模块的执行事件，不是页面浏览或按钮点击的全量统计。托管和自定义 API 模式均会产生业务使用事件，事件都发往 `shared/backend/config.js` 的 RoleMI 后端；自定义模型请求本身不经过 RoleMI AI 网关。

```text
业务入口 → startUsage / trackUsage / cachedUsage
  → chrome.runtime.sendMessage({ type: "rolemi.usage", payload })
  → background.js 校验 sender.id
  → metrics-worker.js 校验并入队 chrome.storage.local
  → POST /api/events { events: [...] }
```

核心代码（路径相对仓库根目录，使用函数名定位，避免行号随注释调整失效）：

| 位置 | 职责 |
| --- | --- |
| `src/shared/backend/config.js`：`USAGE_MODULES` | 业务模块白名单；`AI_MODULES` 另含 `settings_test`，不能混为使用事件 |
| `src/shared/backend/usage.js`：`startUsage` | 创建执行 UUID，立即发送 start，返回至多发送一次终态的结束函数 |
| 同文件：`trackUsage` | 正常返回记 success，抛异常记 failed，再抛出原错误 |
| 同文件：`cachedUsage` | 显式记录一组 start/success，不请求模型 |
| `src/background.js`：`onMessage`、`onAlarm` | 接收安装和使用消息；入队后、Worker 启动及每分钟闹钟触发 flush |
| `src/shared/backend/metrics-worker.js`：`installationId`、`enqueueUsage`、`flushUsage` | 安装 ID、串行持久化、队列去重、分批补发 |

## 2. 上报字段

业务层 payload 只允许以下前四个字段，后台补入安装标识。没有任意 properties 或业务对象字段。

| 字段 | 类型 / 取值 | 来源与含义 |
| --- | --- | --- |
| `module` | string，10 项白名单之一 | 业务调用处传入；见下一节 |
| `execution_id` | UUID v4 | 每次 `startUsage()` 调用生成；同次自动重试不新建执行 |
| `event` | `start` / `success` / `failed` | 开始或终态；没有 cancelled、cache_hit、click 事件 |
| `date` | `YYYY-MM-DD` | 开始执行时取得的客户端 UTC 日期；跨午夜终态仍用开始日期 |
| `installation_id` | UUID v4 | Background 入队时从 `rolemi.installationId` 读取或创建 |

请求示例（虚构标识）：

```json
{
  "events": [
    {
      "installation_id": "11111111-1111-4111-8111-111111111111",
      "module": "resume_match",
      "execution_id": "22222222-2222-4222-8222-222222222222",
      "event": "start",
      "date": "2026-09-26"
    }
  ]
}
```

匿名 ID 标识扩展安装实例，不代表自然人或硬件设备；多面板创建经后台串行锁避免竞争。清除该存储键后可生成新标识。托管 `/api/ai` 使用同一安装标识，但业务执行 ID 不传入 AI 请求，不能按 execution_id 精确关联某次执行与模型调用。

## 3. 业务埋点位置、触发条件和结算边界

所有模块都使用上表公共字段，没有模块专属业务信息。

| module | 埋点位置 | start 触发条件 | success / failed 口径与不触发条件 |
| --- | --- | --- | --- |
| `jd_extract` | `src/app/controllers/jobs-controller.js`：`bindJobsEvents` 的 `#extractBtn` 监听器 | 点击提取，调用 `extractFromCurrentTab` 前 | 岗位更新成功即 success，重复 JD 也成功；不支持的网址、提取或保存异常记 failed。success 在页面刷新前结算 |
| `jd_manual` | 同文件：`#manualJobForm` submit 监听器 | submit 到达且未处于 saving 状态，在 `createManualJob` 前 | 业务校验失败或保存异常记 failed；新增或重复记录均记 success。浏览器原生校验阻止 submit、只打开/取消表单、saving 时重复提交不计 |
| `favorite` | 同文件：`toggleStar` | 目标岗位存在，开始 `updateJobs` | 更新正常返回即 success，异常记 failed；收藏和取消收藏合并统计，不上传方向或岗位 ID。岗位不存在不计 |
| `resume_import` | `src/features/resume/workflow.js`：`handleResumeFile` | 选定文件并进入解析流程 | 解析、结构化和保存后未被 `resumeBlockingMessage` 阻断记 success；解析异常、超长或已有非简历拒绝记录记 failed。首次上传随后被 AI 判为非简历，不回改已结算的 import，而由 resume_profile 记 failed |
| `deep_analysis` | `src/app/task-runner.js`：`runDeepAnalysis` | 依赖键有效，创建请求 ticket 前；包括用户分析及匹配自动补齐 | 有效结果写回且依赖仍有效记 success；当前请求异常记 failed。有效的“非 JD”判定也是分析 success。Controller 提前拒绝的输入不计；过期返回可仅有 start |
| `resume_profile` | 同文件：`runResumeUnderstanding` | 上传后的理解或匹配补齐；未命中缓存且未复用在途 Promise 时 | 新结果保存且可复用记 success；当前版本理解异常、非简历判定或保存后不可复用记 failed。无简历、已阻断简历不计；复用同版本在途 Promise 不新计；换简历或保存返回空可仅有 start |
| `resume_match` | 同文件：`runResumePipeline` | 岗位与简历理解前置都就绪、输入有效且依赖键存在后 | 当前结果写回成功记 success；当前请求异常记 failed。前置失败、非 JD、无效简历等阻止进入 Match 时，不产生该模块事件；查看已有匹配结果不计缓存使用 |
| `resume_revision` | 同文件：`runResumeRevision` | Match 成功后的自动执行，或点击修改建议重试；有效 Match 且 Match/Revision 均未在途 | 当前 ticket 的结果处理完成记 success，合法空建议列表也成功；当前请求异常记 failed。无有效 Match、简历阻断、在途重复点击不计。仅展开、查看已有建议不计 |
| `greeting` | 同文件：`runGreeting` | 生成/重新生成流程进入任务且依赖键有效 | 当前结果写回成功记 success；当前请求异常记 failed。无依赖键不计；查看缓存、编辑、复制或只修改选项不计 |
| `excel_export` | `src/features/jobs/export.js`：`exportJobs` → `downloadWorkbook` | 导出列表非空，开始生成工作簿 | 工作簿及下载 API 调用正常返回记 success，异常记 failed；不保证文件最终保存成功。空列表不计，导出全部与仅收藏未分维度 |

Revision 的 success 当前在写入流程返回后以 `requests.isCurrent(revisionTicket)` 结算；写入回调另校验 Match resultId 和完整依赖。事件没有“实际写入条数”字段，不应据 success 推导保存条数。

### 显式缓存计数位置

| module | 位置 | 条件 |
| --- | --- | --- |
| `deep_analysis` | `src/app/controller.js`：`openJobFromList` | 从列表打开 analysis、未要求重新分析且缓存有效 |
| `deep_analysis` | `src/app/controllers/detail-controller.js`：`analyzeCurrentJobIfNeeded` | 点击详情分析入口且已有可复用分析 |
| `deep_analysis` | `src/app/task-runner.js`：`runResumePipeline` | 匹配前无需重建岗位理解 |
| `resume_profile` | 同文件：`runResumeUnderstanding` | 命中内存或同一简历版本的持久化有效结果 |
| `resume_profile` | 同文件：`runResumePipeline` | 匹配前无需重建简历理解 |

仅以上显式入口计缓存使用。普通 tab 切换、页面刷新与恢复不普遍计数。`resume_match / resume_revision / greeting` 没有 `cachedUsage` 调用。事件也没有标明缓存来源，因此仅凭 `/api/events` 无法计算缓存命中率。

## 4. 执行、成功率与重试口径

- 每次执行发出 start，**至多**发出一个终态。结束函数重复调用忽略；过期响应、提前返回、关闭面板或消息丢失可能没有终态，没有自动补齐机制。
- AI 内部 Compact Retry 或参数兼容重试处在同一次业务执行内，共用一个 execution_id；用户手动重试重新进入任务时创建新执行。
- 一次 Match 操作可能产生 deep_analysis、resume_profile、resume_match、resume_revision 多个模块执行；前两者可能是缓存使用或自动补齐，不能把模块 start 总和当成用户点击次数。
- `success / start` 为启动口径成功比例；`success / (success + failed)` 为已结算口径成功比例，两者需明确分母。start 与终态不必齐全，缺口不能直接视为业务失败。
- 日期按客户端 UTC，不是日本时间或浏览器本地日期。客户端时间偏差、队列丢弃及批次乱序会影响观察结果。
- 安装数按 installation_id 去重；业务使用次数按 execution_id 去重。模型调用量与 Token 来自 AI 网关成本记录，仅覆盖托管请求，不能等同业务使用量。

## 5. 持久化队列与补发

| 项目 | 当前实现 |
| --- | --- |
| 存储 | `chrome.storage.local`：`rolemi.installationId`、`rolemi.usageQueue` |
| 来源校验 | Background 仅处理 `sender.id === chrome.runtime.id` 的消息 |
| payload 校验 | 仅允许 date/event/execution_id/module 四键；模块枚举、UUID v4、事件枚举及日期格式检查 |
| 入队日期窗口 | `Date.now() - Date.parse(date)` 须有限，范围为 -1 天至 7 天；格式和可解析性检查不等同严格日历校验 |
| 本地去重 | 队列已有相同 execution_id + event 时不重复加入；不跨清空后的队列永久去重 |
| 容量 | 入队前过滤年龄小于 7 天的已有事件，加入后保留末尾 200 条，溢出丢弃旧条目 |
| 批次 | 每次取年龄小于 7 天的前 40 条；单次 flush 不循环排空全部队列 |
| 触发 | Worker 模块加载、入队完成后、`rolemi.usage.flush` 每分钟闹钟 |
| 并发 | 同时 flush 复用在途 Promise；安装 ID 和队列读写使用串行锁 |
| 请求 | POST `/api/events`，JSON `{ events: batch }`，超时 8000 ms |
| 删除 | HTTP 2xx 或 400/413 后按 execution_id + event 删除该批，不检查响应 JSON 的逐条确认 |
| 重试 | 网络异常、超时及其他非 2xx 状态保留批次，等待下次触发；不是无限可靠投递 |

过期条目在 flush 选批时跳过，在后续入队时清理；没有新入队时可能仍保留在本地。服务端最终去重、聚合和保留周期属于相邻后端仓库，接口及部署说明见 [backend.md](backend.md)，不能用前端队列保证替代服务端验收。

## 6. 本地调试统计与远端成本记录

`src/shared/ai/debug.js` 的 `recordDeepAnalysisReliability` 在 `src/features/jd-analysis/service.js` 调用，使用 Web `localStorage` 的 `rolemi.deepAnalysisReliability`，与扩展使用事件队列分开：

| 字段 | 触发 |
| --- | --- |
| `firstAttempt` | 开始首次深度分析模型尝试；缓存复用不进入该计数 |
| `retry` | 首次发生可重试的输出错误，进入 Compact Retry |
| `finalFailure` | 首次遇到不可重试错误，或 Compact Retry 仍失败；输入/配置预检失败不计 |
| `updatedAt` | 最近一次计数更新的 ISO 时间 |

`ROLEMI_DEBUG_API.stats()` 查看，`resetStats()` 重置；计数不通过 `/api/events` 上传。Debug 默认关闭，通过 `enable()` 开启受限状态、耗时、预算和错误类别日志，不打印业务正文。

服务端 `ai_calls` 成本记录与本地计数不同：托管网关实际模型尝试可能因内部重试多于模块使用次数；自定义 API 模式的模型调用不进入 RoleMI `ai_calls`。

## 7. 未采集项与隐私边界

`/api/events` 不包含 JD/简历正文、标题、公司、文件名、Prompt、AI 输出、错误正文或堆栈、岗位 ID、搜索词、API Key；也不记录页面浏览、普通步骤切换、清空岗位、清除简历、复制、编辑和设置保存。连接测试 `settings_test` 属于 AI 请求模块，不是业务使用事件。

完成 AI 推理所需文本会通过托管 `/api/ai` 或用户自定义 Responses API 发送，这是模型调用链路，与使用事件分开。事件中的安装 ID 是可跨请求关联的匿名标识，不应宣称完全不可关联。

## 8. 验收与排障

1. 运行 `npm test`。`tests/backend.test.mjs` 已覆盖安装 ID 并发、离线补发、结束函数去重、缓存 API、自动重试计数和上报失败隔离；测试使用模拟网络，不代表线上已收数。
2. 在扩展后台 Service Worker DevTools 查看 Network 的 `/api/events`，核对 method、5 个事件字段、模块枚举与 UTC 日期。业务完成后队列可能立即清空，空队列本身不是漏埋证据。
3. 断开本地后端后执行一次收藏，再读取 `chrome.storage.local.get(['rolemi.installationId', 'rolemi.usageQueue'])`；应看到同一 execution_id 的 start 和 success。恢复后端后等待下一次闹钟或业务事件，确认补发与队列删除。
4. 重复保存同一 JD 应记 success；只取消手动表单、查看已有 Match 或复制 Greeting 不应新增对应事件。
5. 匹配前缓存有效时观察 deep_analysis / resume_profile 的 start+success；不要预期 resume_match 缓存事件，也不能从事件字段本身识别缓存。
6. 模拟自动重试，确认同模块只有一次 start 与至多一个终态；手动重新发起任务应换 execution_id。更换简历造成过期时允许保留未结算 start。
7. 无上报时先检查扩展上下文、BACKEND_URL、后台消息及队列；后台回复 ok 仅表示入队调用返回，不能证明服务端接收，非法 payload 也可能被静默忽略。
