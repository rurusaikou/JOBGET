# RoleMI 架构说明

## 1. 一句话理解

当前 v2.7.0 使用三层代码结构，并在业务上维护两个可复用的 Understanding 结果：

```text
App（页面与工作流）
        ↓
Features（单一业务能力）
        ↓
Shared（跨功能基础设施）
```

业务数据流：

```text
Raw JD     → Job Understanding     → Job Profile
Raw Resume → Candidate Understanding → Resume Profile
                                      ↓
                         Job Profile × Resume Profile
                                      ↓
                                    Match
```

依赖方向保持单向：`app → features → shared`。

## 2. 总体结构

```text
src/popup.js
   ↓
app/controller.js
   ├── controllers/           DOM 事件与页面交互
   ├── runtime.js             全局 State / Request Registry / 写入队列
   └── task-runner.js         AI 工作流编排与依赖补齐
          ↓
features/
   ├── jobs/                  提取、手动录入、去重与岗位存储
   ├── jd-analysis/           Job Understanding
   ├── resume/                文件提取 + Resume Understanding + Profile 缓存
   ├── resume-match/
   ├── resume-revision/
   └── greeting/
          ↓
shared/                       AI / Context / Storage / UI / Config
```

## 3. App 层

### `app/controller.js`

只负责组装 Controller、初始化数据和全局 refresh，不承载 Prompt、Provider 适配或 Response Parser。服务设置、岗位池和简历按独立容错边界恢复；一项读取失败不会阻断其余本地数据加载，最终在首页状态区汇总失败模块。

### `app/controllers/jobs-controller.js`

负责提取与手动表单、搜索、收藏、导出和清空。手动录入走 `features/jobs/manual.js` 校验与构造字段，网页提取走 `features/jobs/extract.js` 的网址预检与页面消息；两者都经 `runtime.updateJobs()` 的串行队列调用 `repository.js` 去重、保存。

`navigation-controller.js` 管理 `manual` 页面，隐藏顶部岗位池 / 收藏标签；手动保存成功返回 `jobs` 页面。收集 JD 不经过 AI Task Runner。

### `app/controllers/resume-controller.js`

负责：上传简历、展示本地解析 / Resume Understanding 状态、在上传成功后启动一次 Resume Understanding，以及响应用户操作触发 Match / Revision。

它不理解简历内容；真正的文件读取和 AI 结构化都在 `features/resume/`。

### 顶部辅助入口

`navigation-controller.js` 管理三点菜单以及服务设置、使用帮助、反馈建议三个辅助页面的返回路径。帮助内容直接使用原页 `details` 抽拉项，各项由浏览器独立控制，可同时展开多个，不再切换独立详情页。`feedback-controller.js` 从运行时本地岗位池生成关联岗位下拉，提交反馈类型、正文和可选岗位 ID；选择岗位时同时提交该岗位 JD 与已生成的分析结果快照，不提交简历原文或附件。

### `app/runtime.js`

集中持有 App State、Request Registry、岗位串行写入队列，并把持久化结果同步成 UI Task State。

### `app/task-runner.js`

负责 AI 工作流和依赖补齐。

Match 前会检查：

```text
Job Profile 是否有效？
Resume Profile 是否有效？
```

如果缺失：

- Job Profile → `runDeepAnalysis()`；
- Resume Profile → `runResumeUnderstanding()`；
- 两者都缺失 → 并行执行。

两者 Ready 后才创建 Match ticket。正常上传流程会提前准备 Resume Profile，但不会因此自动创建 Match ticket；Match 仍由用户点击“匹配”触发。

## 4. Resume Feature 的职责边界

`features/resume/` 现在分成两层：

```text
File Parsing
├── pdf.js / docx.js
├── parser.js
├── normalize.js
├── sections.js
└── extractor.js

Resume Understanding
├── profile-prompt.js
├── profile-service.js
├── profile-response.js
└── storage.js
```

### Local Parser

负责从 PDF / DOCX 获取可用文本，并提供基础结构索引。它允许漏识别章节，因为它不再是 Match 的最终事实结构来源。

### Resume Understanding

读取完整 `rawText`，用 AI 识别实际语义结构，重点保证工作项目、科研项目、平台建设等内容进入 `projects`。

### Profile Cache

Profile 与 `resume.contentVersion` 绑定。相同内容复用；内容或 Profile / Prompt 版本变化后失效。

## 5. Match 的新边界

Match 不再承担两侧材料的完整理解。

```text
Job Profile + Resume Profile → Match(none)
```

因此正常路径没有：

```text
Raw JD → Match
Raw Resume → Match
```

Match 已经消费两侧结构化 Profile，因此关闭额外 reasoning；其职责是比较证据并完成结构化判断，而不是重新理解长原文。

## 6. UI 状态

Match 首次使用 `none + 4000`；若结构化结果因输出预算或 incomplete JSON 未完成，只执行一次 Match Compact Retry（`none + 6000`），优先完成紧凑 JSON。

Match 与 Revision 仍采用显式四态：

```text
idle → loading → success
           └──→ error
```

Resume 自己有两个预处理状态：

```text
parsing        本地读取 PDF / DOCX
understanding  AI 生成 Resume Profile
```

Resume Understanding 失败时，本地提取结果仍保留；用户再次点击“匹配”可重试 Profile 生成。

## 7. 依赖与旧请求保护

Match dependency key 包含：

```text
Job Version
Deep Analysis resultId
Resume Version
Resume Profile resultId / version
```

所以：

- JD 变化 → Job Profile / Match 失效；
- Resume 变化 → Resume Profile / Match 失效；
- Resume Profile Prompt 或 schema 升级 → 旧 Profile 不再复用；
- 重新生成 Profile → 旧 Match 不再视为当前结果。

Revision 额外绑定当前 Match `resultId`。

## 8. Deep Analysis 可靠性层

Deep Analysis 正常使用完整 JD + `low + 4000`，Prompt 对各字段设置表达预算并禁止重复复述。

只对 `max_output_tokens` / incomplete JSON 自动 Retry 一次：高信号压缩 JD + `none + 5000`，并使用 Compact Retry 指令优先完成完整 JSON。

Provider 参数兼容 Retry 与这个业务 Retry 是两套不同机制。

## 9. 从哪里开始读代码

```text
popup.js
  ↓
app/controller.js
  ↓
app/controllers/*
  ↓
app/task-runner.js
  ↓
features/jd-analysis/ 或 features/resume/
  ↓
shared/context + shared/ai
```

如果你在排查“项目经历为什么没进入 Match”，优先读：

```text
features/resume/profile-prompt.js
→ profile-service.js
→ profile-response.js
→ shared/context/builders.js
```

## 托管服务与统计后台

`shared/backend/config.js` 集中发布地址及模块枚举；`shared/ai/client.js` 统一适配托管 Gateway 或用户自定义 Responses API 调用。`shared/backend/usage.js` 提供模块执行标识与结算；`metrics-worker.js` 在 module service worker 中串行生成安装标识、持久化最小事件队列并用 alarms 补发。网络失败与业务流程隔离。

Cloudflare Worker + D1 固定上游密钥/模型，在次数限额开启时原子预占，始终限制输入/输出；events 原子触发匿名安装去重和日汇总，30 天清理明细。无简历/JD/Profile 云端存储或公开统计接口。本地/生产配置、扩展 Origin 与访问控制限制见 [后端接入说明](backend.md)。

### AI 请求路由

架构层只约束 `shared/ai/client.js` 作为统一请求适配器；具体托管/自定义选择、失败和恢复规则统一维护在 [AI 流程](ai-pipeline.md#ai-请求路由)，配置持久化边界见 [数据模型](data-model.md#服务设置与请求策略)。

### 修改建议等待与重试

控制器负责请求代次隔离与页面状态同步，Task Runner 负责匹配结果复用和 Revision 重试。完整等待、失败与过期响应规则统一维护在 [AI 流程](ai-pipeline.md#修改建议等待与重试)，产品层交互约束见 [实现契约](feature-spec.md#修改建议等待与重试)。
