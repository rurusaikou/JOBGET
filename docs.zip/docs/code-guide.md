# RoleMI 代码阅读指南

## 1. 先记住调用链

```text
DOM Event
   ↓
Controller
   ↓
Task Runner
   ↓
Feature Service
   ↓
Shared Context / AI / Storage
```

现在还有一条很重要的数据链：

```text
Raw JD → Job Profile ─┐
                      ├→ Match
Raw Resume → Resume Profile ┘
```

## 2. 第一次阅读源码

建议顺序：

1. `src/app/state.js`：先看状态；
2. `src/app/task-runner.js`：看 Profile 如何补齐、Match 如何启动；
3. `src/features/jd-analysis/`：看 Job Understanding；
4. `src/features/resume/`：看 Local Parser 与 Resume Understanding；
5. `src/shared/context/builders.js`：确认 Match 真正发送什么；
6. `src/shared/context/cache.js`：理解版本与失效；
7. `src/shared/ai/client.js`：最后看 Provider / Responses API 适配。

## 3. Resume 一侧怎么读

```text
上传文件
  ↓
parser.js
  ↓
pdf.js / docx.js
  ↓
extractor.js                 本地 rawText + 辅助结构
  ↓
storage.js                  计算 Resume contentVersion
  ↓
resume-controller.js         上传后立即触发一次 Resume Understanding（不自动 Match）
  ↓
profile-service.js           AI Resume Understanding
  ├── profile-prompt.js
  └── profile-response.js
  ↓
storage.js                  保存 Resume Profile
  ↓
builders.js                 Match 只读取 Profile
```

如果出现 `projects: []`，先区分：

- 本地 `resume.projects` 为空：可以接受，它只是辅助 Parser；
- `resume.profile.projects` 为空：会直接影响 Match，需要重点排查 Resume Understanding。

## 4. 按问题定位

| 问题 | 优先查看 |
|---|---|
| 手动添加校验、计数、保存和返回 | `features/jobs/manual.js` → `app/controllers/jobs-controller.js` → `popup.html` |
| 不支持的网址仍尝试提取 | `features/jobs/extract.js` → `content.js` |
| 岗位重复或保存后丢失 | `features/jobs/repository.js` + `app/runtime.js` |
| PDF / DOCX 读不出文本 | `features/resume/pdf.js` / `docx.js` |
| 本地章节识别不准 | `sections.js` / `extractor.js` |
| 科研/工作项目没进 Profile | `profile-prompt.js` → `profile-response.js` |
| 同一简历重复调用 AI | `storage.js` + `cache.js` 的 Profile 版本判断 |
| Match 仍发送原始简历 | `shared/context/builders.js` |
| Match 状态异常 | `runtime.js` → `resume-controller.js` |
| Deep Analysis Retry | `jd-analysis/service.js` + `builders.js` |
| Revision 失败 | `task-runner.js` → `resume-revision/` |
| Greeting 失败 | `greeting-controller.js` → `greeting/` |
| JSON / reasoning / Provider | `shared/ai/client.js` + `errors.js` |

## 5. 四个容易误解的点

### 5.1 本地 Parser 不再决定 Match 能看到什么

Local Parser 的职责是把文件变成可读取文本，并提供基础索引。真正给 Match 用的是 AI 生成的 Resume Profile。

### 5.2 Resume Profile 不是摘要

它应该减少结构噪声，但不能主动删掉影响匹配的事实。项目职责、技术、量化成果要尽量保留在 `details`。

### 5.3 两个 Profile 都是 Match 硬依赖，但不是用户操作门槛

上传简历成功后，`resume-controller.js` 会先调用 `runResumeUnderstanding()` 生成缓存，但不会自动开始 Match。用户点击“匹配”后，`runResumePipeline()` 会自动补齐缺失的 Job Profile / Resume Profile；两个都缺时并行准备。

### 5.4 Greeting 不重新读取 Resume Profile

Greeting 消费 Job Profile 中的岗位本质 / 核心要求，以及 Match Result 中的直接匹配证据 / 可迁移能力；不重新读取完整 Resume Profile。Resume 仍参与 dependency key，是为了换简历后旧 Greeting 自动失效。

## 6. 修改代码前检查

1. 这次改动属于 JD 收集、File Parsing、Understanding、Match 还是 Generation？
2. 是否改变 Resume Profile schema / Prompt？如果是，必须升级版本并让旧缓存失效。
3. 是否可能让 Raw JD / Raw Resume 重新进入正常 Match？
4. 是否保留了事实 Evidence，而不是只留下高层总结？
5. 是否会对同一 Resume Version 重复调用 Resume Understanding？
6. 代码修改后是否同步更新文档和测试？

## 托管服务与统计代码

- `src/shared/backend/config.js`：维护者配置后端地址及模块白名单。
- `src/shared/backend/usage.js`：startUsage / trackUsage / cachedUsage，业务不得把正文或错误放进事件。
- `src/shared/backend/metrics-worker.js`：后台安装 UUID、串行队列、重发和去重。
- `src/shared/ai/client.js`：hosted envelope 和统一错误。
- `tests/backend.test.mjs`：托管请求隐私、队列、重试与缓存计数。

后端仓库包含 SQL 初始化、旧库升级与 report.sql；详情见 [后端接入说明](backend.md)。

### 服务设置与请求策略

代码职责以本节上方的文件清单为准；完整 UI 行为见 [实现契约](feature-spec.md#服务设置与请求策略)，存储字段与密钥生命周期见 [数据模型](data-model.md#服务设置与请求策略)，请求路由与失败策略见 [AI 流程](ai-pipeline.md#ai-请求路由)。本文件不重复维护易变化的字段文案与恢复步骤。

## 源码头部注释约定

`src/` 下的自有 JavaScript 文件统一在首个可执行语句或 import 前放置模块说明，解释职责、调用边界或关键约束；已有说明保留并归位。`popup.css` 在顶部说明样式范围，`popup.html` 在 DOCTYPE 后说明页面入口。第三方 `src/vendor/` 文件保留原始许可证和内容；JSON 配置不加入非法注释。测试文件以测试名称描述验证行为。

`tests/docs-consistency.test.mjs` 会动态枚举 `src/` 下除 `vendor/` 外的全部 JavaScript 文件，并检查它们是否都在首个语句前保留模块说明；文档不再复制易变化的文件总数。复杂分支继续就近说明状态优先级、兼容原因或并发约束；不为从命名即可理解的赋值和 DOM 操作逐行复述。

头部注释不复制易变的版本号或预算值；精确数值以配置和 [实现契约](feature-spec.md) 为准。埋点修改同时更新 [埋点说明](metrics.md)，明确模块入口、成功边界、未上报分支及缓存口径。
