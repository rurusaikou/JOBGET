# RoleMI AI Pipeline

## 1. 总览

RoleMI 把 AI 任务分成三层：Understanding、Reasoning、Generation。

```text
             Understanding Layer

Raw JD ─────→ Deep Analysis ─────→ Job Profile
                                      \
                                       \
                                        → Match → Match Result
                                       /
Raw Resume ─→ Resume Understanding → Resume Profile

             Generation Layer
                   ↓
             Revision / Greeting
```

核心规则：**Match 只比较 Job Profile 与 Resume Profile。正常路径不重新发送 Raw JD / Raw Resume。**

## 2. 任务配置

| 任务 | 目的 | Reasoning | 主要输入 | 是否缓存 |
|---|---|---:|---|---|
| JD 深度分析 | 理解岗位本质、优先级、隐形要求 | `low`（Retry=`none`） | Raw JD | 按 Job Version |
| Resume Understanding | 忠实抽取候选人事实并组织成 Profile | `none` | Raw Resume | 按 Resume Version |
| Resume Match | 比较两个 Profile | `none`（Retry=`none`） | Job Profile + Resume Profile | 按两侧 Profile 版本 |
| Resume Revision | 筛选能增强岗位匹配证明力的修改动作 | `none`（Retry=`none`） | Target Job（title）+ Resume Profile + Match Result | 随 Match |
| Greeting | 生成首次沟通文案 | `none` | 岗位本质 + 核心要求 + 直接匹配 + 可迁移能力 | 随 Match + 参数 |

### 各任务实际输入

下表列出提供给模型的业务数据，不包含 Prompt 指令及输出 Schema。

| 任务 | 输入内容 |
|---|---|
| Deep Analysis | 岗位名称、公司、地点、经验、学历、薪资、完整 JD（首次请求） |
| Resume Understanding | 完整简历 `rawText`，由独立服务直接构建 Prompt |
| Match | 岗位基础事实＋Job Profile＋Resume Profile |
| Revision | Target Job（岗位名称）＋当前 Match 使用的 Resume Profile＋直接匹配 / 可迁移能力 / 关键缺口 |
| Greeting | 岗位本质＋核心要求＋直接匹配证据＋可迁移能力＋沟通风格/内容长度 |

Deep Analysis、Match、Greeting 通过 `src/shared/context/builders.js` 的 `buildTaskContext()` 按任务组装输入；Resume Understanding 和 Revision 由各自服务调用 Prompt 构建函数组织输入。

Match 不发送完整 JD，也不回退完整简历；Resume Profile 的缓存元数据在进入 Match 前移除，仅保留业务字段。Greeting 读取岗位本质、核心要求以及 Match 的直接匹配 / 可迁移能力，由 Greeting Prompt 自己按岗位重要性、证据强度和区分度筛选要表达的优势。

## 3. Job Understanding：Deep Analysis

第一次请求使用岗位基础字段和完整 JD；`reasoning=low`。Prompt 已提供固定分析框架，优先降低 reasoning 开销，同时保留岗位本质、核心要求优先级、隐形要求和理想候选人判断。

第一次预算：`4000 output tokens`。最终表达按字段设置紧凑预算，避免重复 JD 和跨字段复述。

JD 分析 Prompt v5 在 system 消息中限定招聘材料为分析对象，user 消息包含七步分析任务、判断规则和岗位材料；四个模块分别回答岗位本质、核心要求、有依据的隐形要求和理想候选人画像。新增顶层 isJobDescription、nonJdReason，非 JD 返回原因和四个空数组，停止下游任务。四个分析字段保留，其中 hiddenRequirements 改为 { requirement, basis } 对象数组。Job Summary 的 inferredRequirements 也保留这一结构；Match 将依据视为 JD 推断依据，不是候选人事实。旧 Prompt 版本的分析缓存失效。

只有出现 `max_output_tokens` 或最终 JSON 不完整时，自动 Retry 一次：

```text
完整 JD + low + 4000
        ↓ incomplete
高信号压缩 JD（description ≤ 3200 chars）
        ↓
none + Compact Retry + 5000
```

Retry 关闭额外 reasoning，并追加 Compact Retry 指令：不重新展开分析过程，优先保证完整 JSON，压缩重复解释。

## 4. Candidate Understanding：Resume Profile

### 4.1 两阶段解析

简历处理不是“AI 直接读文件”，而是：

```text
PDF / DOCX
   ↓
Local Parser
   ├─ 提取 rawText
   └─ 生成基础结构（仅辅助 / 调试）
   ↓
Resume Understanding（AI, none）
   ↓
Resume Profile
```

本地 Parser 负责**读文件**；AI 负责**理解弱结构化内容**。

### 4.2 为什么不是普通摘要

Resume Profile 的目标是保存匹配证据，而不是尽量变短。它会组织：

- education
- workExperience
- projects
- skills
- certifications
- languages
- otherEvidence

其中 `projects` 会主动识别工作项目、科研项目、课题、知识库、平台建设、迁移等内容，不依赖章节标题必须叫“项目经历”。

每个项目保留 `name / role / period / organization / details / technologies`。`details` 是下游 Match 和 Revision 的事实证据。

### 4.3 触发与缓存

简历本地提取后先检查 rawText.trim().length，超过 4000 字时保留文档并提示超限，不进入任何后续分析。未超限且没有当前内容的非简历拒绝记录时，上传后会触发一次 Resume Understanding 并缓存结果；这个预处理不会自动启动 Match。用户之后点击“匹配”时，如果 Profile 已有效就直接复用；如果此前因网络等临时原因失败或已失效，Task Runner 再自动补齐。validResume=false 则保存拒绝记录，重新打开也不重复请求；更换文档后重新判定。

Resume Profile 绑定当前 `resume.contentVersion`、Profile schema version 和 Prompt version。

同内容重新上传时可复用；简历正文变化、Profile schema 变化或 Resume Profile Prompt 变化时自动失效。

Resume Understanding 使用 `reasoning=none`：这是事实抽取与归一化任务，不需要额外推理；同时减少延迟和无关输出。

## 5. Match：Job Profile × Resume Profile

点击“匹配”时：

```text
检查 Job Profile        检查 Resume Profile
      │                        │
缺失 ─┘                        └─ 缺失
  ↓                               ↓
Deep Analysis              Resume Understanding
      \                         /
       \—— 两者都 Ready ——/
                ↓
              Match
```

如果两个 Profile 都缺失，Task Runner 使用 `Promise.all` 并行准备，而不是串行等待。

Match 使用 `reasoning=none`，只回答：

- 整体匹配等级与原因；
- 直接匹配；
- 可迁移能力；
- 关键缺口。

**Match 不回退 Raw JD，也不回退 Raw Resume。**

Match 最终表达采用字段级压缩，避免在 requirement / experience / proof / boundary 之间重复同一信息。首次预算为 `4000`；如果因 `max_output_tokens` 或 incomplete JSON 未完成，只自动 Compact Retry 一次（`none + 6000`），不重新展开分析，不新增判断维度，优先保证完整 JSON。

## 6. Revision

Revision 使用当前 Match 所消费的 Resume Profile + Match Result（直接匹配、可迁移能力、关键缺口），同时发送 Target Job 的 `title`，不重新发送完整 JD / Resume 原文。岗位来自当前 Match 的 `snapshot.job`，通过 `generateResumeRevisions({ ..., job })` 传入；首次和重试均调用 `resumeRevisionMessages({ resumeProfile }, matchResult, job, { compact })`。缺少岗位名称时使用“未提供”。

`reasoning=none`，首次输出预算为 `5000` tokens。所有改写必须可追溯到 Resume Profile；`original` 只引用最相关的原始内容，避免大段引用。

当返回 `max_output_tokens`、JSON 无法解析或空输出时，自动执行一次 Compact Retry：改用 `reasoning=none`、`8000` tokens，沿用相同输入与 Schema，压缩重复表达，保留筛选标准、事实边界和全部必填字段。合法的空建议列表不重试；网络、API 错误及其他 incomplete 原因不触发此重试。第二次失败直接上报，不循环重试。控制台重试标签为 `resume-revisions:retry`。

Revision 失败不会改变 Match success。

Revision 输出字段为 `category / summary / original / rewrite / reason`。`category` 取值为“事实优化 / 策略强化 / 经历补充”。`summary` 表达一个明确修改方向；`reason` 说明原文问题及修改的具体增益，或需要确认的真实信息。Schema 字段长度上限分别为：`summary` 80、`original` 180、`rewrite` 220、`reason` 160。

Revision 使用 Suggestion Gate，每条候选建议至少满足一种增益：

- **事实表达增益**：已有事实、行动、结果、规模或职责，但表达不清。
- **岗位关联增益**：已有真实经历与岗位核心要求相关，但关联没有清楚表达。
- **证据结构增益**：通过 STAR、因果关系或“行动→结果”重组已有事实，增强证明力。
- **真实信息缺口**：有相关线索但不足以支持改写，只生成“经历补充”，`rewrite` 必须为空。

“事实优化”改善已有事实的表达；“策略强化”重新组织已有事实以突出岗位关联。仅同义改写、堆关键词、追加能力总结、没有实质增益、依赖不存在的事实或重复解决同一问题的建议不输出。Match 明确缺失且无相关线索的问题不进入 Revision；不得升级职责或把可迁移能力改写成直接经验；不得把候选人的业务对象、流程或场景替换为目标岗位业务，也不得仅因 JD 使用某术语就重新定义候选人的经历。

建议按对岗位匹配证明力的提升从高到低排序，不设置固定条数，也不为数量强行生成；实际输出仍受 token 预算和字段长度约束。

前端收起时展示标题、类别标签和摘要说明，不再额外展示原内容或改写预览。摘要优先使用 `reason`，缺失时依次回退到 `rewrite`、`summary`、补充提示。展开后展示原内容（存在时）、修改依据 / 待补充信息及可改为（存在时）。

## 7. Greeting

Greeting 不直接发送 JD 原文，也不直接发送 Resume 原文或完整 Resume Profile。

只发送：岗位本质、核心要求、直接匹配证据、可迁移能力、沟通风格（tone）、内容长度档位。使用 `reasoning=none`。

沟通风格：自然 / 简洁直接 / 积极主动 / 专业正式。内容长度 UI 仅展示“精简 / 标准 / 详细”，分别控制从“只说最核心信息”到“提供更多岗位相关证据和动机”的内容密度，并对应最多使用 1 / 2 / 3 个核心匹配证据。模型返回内容由页面完整展示，前端不做字符截断。

## 8. Context 与隐私

- Resume Profile 不保存姓名、手机号、邮箱。
- Raw Resume 只用于一次性 Resume Understanding，不进入正常 Match。
- Greeting 不读取 Raw JD / Raw Resume。
- 每个任务只消费本任务所需 Context，不附加历史对话。
- 常规 Context 超限直接拒绝，不静默截断。

## 9. Debug

Deep Analysis：

```text
[RoleMI API timing] deep-analysis:first
[RoleMI API timing] deep-analysis:retry
```

Resume Understanding：

```text
[RoleMI API timing] resume-profile
```

Deep Analysis 可靠性统计：

```js
ROLEMI_DEBUG_API.stats()
```

返回 `firstAttempt / retry / finalFailure`。

## 托管网关与统计边界

默认 hosted 请求由 AI Client 发送至 Worker `/api/ai`，包含随机安装 UUID、固定模块名、Responses 请求；不发送 API Key 和指定模型，模型由服务端统一配置。原 Prompt、Context、解析、Compact Retry 和持久化链路保持原规则。

模块统计放在执行/保存外围，一次执行 start + success/failed，重试不重复计数，过期丢弃不计完成；仅已接入 cachedUsage 的 Deep Analysis / Resume Profile 缓存路径单独计一次使用。后台队列异步上报 `/api/events`；服务端 ai_calls 单独统计实际模型尝试和 Token。网关在限额开启时原子预占额度后才调用；completed/incomplete 返回解析层，供应商原始错误不回显。Debug 仅保留状态、时长、预算与计数，不打印输入/输出正文。详见 [后端接入说明](backend.md) 与 [埋点说明](metrics.md)。

### AI 请求路由

默认使用 RoleMI 后端；配置以 `mode: hosted/custom` 决定路由，`provider` 仅保留实际模型供应商，`apiType` 当前固定为 `responses`。旧版 `provider: hosted/custom/厂商名` 会在读取时迁移。用户保存自己的 API 地址、模型名称和 API Key 后，优先直连用户的 Responses API；Base URL 自动追加 `/responses`，完整 `/responses` 地址保持不变，`/chat/completions` 会被明确拒绝。入口开关不参与路由判断。自定义配置无效或请求失败时不回退托管；用户点击“恢复默认服务”会清除自定义配置及会话密钥并切回托管，清空三个字段后保存也有相同效果。

### 修改建议等待与重试

修改建议生成期间，每 4 秒轮播一个分析主题（岗位关联、经历证据、表达清晰度、建议优先级），完成后自动展示结果；主题仅用于等待展示，不代表真实推理进度，不显示虚假百分比。减少动态效果偏好下展示静态主题。失败时仅展示一行“重新生成修改意见”，文字后紧跟循环箭头重试按钮（带同名无障碍标签），不展示模型原始错误和重复提示；重试复用当前有效匹配结果，只请求 Revision，不重复 Match。同一任务重复点击不会重复发起请求，旧岗位/简历结果不得覆盖当前结果。

本文输出 Token 数值表示插件请求预算。当前托管网关对 Resume Profile / Match / Revision 另有较低上限，最终值见 [后端预算差异表](backend.md)；自定义 API 不经过 RoleMI 网关。
