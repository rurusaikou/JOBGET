# RoleMI 数据模型与状态规则

## 1. 持久化数据与运行时状态

RoleMI 同时维护：

- **持久化数据**：Job、Resume、Job Profile、Resume Profile、Match、Greeting；
- **运行时状态**：当前页面、文件解析进度、Resume Understanding 进度、AI request loading/error。

当前品牌为 RoleMI。浏览器存储统一使用 `rolemi.jobs`、`rolemi.resume`、`rolemi.settings`、`rolemi.installationId` 和 `rolemi.usageQueue`，早期技术前缀不再使用。

## 2. Job

```text
Job
├── id
├── contentVersion
├── title / company / location / salary / ...
├── description
├── sourceSite / sourceUrl / starred
├── summary
├── deepAnalysis       ← Job Profile 来源
├── resumeMatch
└── greeting
```

`contentVersion` 只由影响岗位语义的内容计算。收藏等 UI 属性不改变版本。

### 手动录入与去重

手动录入的 `sourceSite = "手动添加"`，`sourceUrl = ""`。职位名称、公司 / 地点、岗位信息、薪资分别保存到 `title / company / experience / salary`；组合字段不自动拆分，`location / education` 保持空值。正文保存到 `description`，各项去除首尾空白。正文上限为 2000 UTF-16 字符，校验长度包含输入的首尾空白。

`repository.js` 去重保留第一条记录，不覆盖已有收藏或 AI 结果：

- 网页 JD：URL + 职位名称 / 公司 / 地点 / 薪资；无 URL 的非手动记录回退到这些基本信息，不比较正文。
- 无 URL 的手动 JD：单独的手动来源标记 + 上述基本信息 + `experience` + 正文。同名但正文不同可分别保存，仅填写正文的相同 JD 也能去重。
- 去重比较时合并连续空白、去除首尾空白并忽略大小写；因此只在空白或大小写上不同的正文视为相同。

手动保存仍生成稳定 ID、内容版本和摘要。未填写标题时，岗位卡片显示“未识别职位名”；保存本身不生成 Job Profile。

## 3. Resume

```text
Resume
├── id
├── contentVersion
├── source
├── rawText
├── basicInfo
├── education / workExperience / projects / ...   ← 本地 Parser 的辅助结构
├── sections                                      ← 本地辅助索引
├── summary                                       ← 兼容保留的本地摘要
└── profile                                       ← Match 真正消费的 Resume Profile
```

`rawText`、本地结构字段和 sections 参与 `contentVersion`；`profile` 是派生缓存，不参与内容哈希。

## 4. Resume Profile

简化结构：

```text
Resume.profile
├── resultId
├── version
├── promptVersion
├── sourceVersion        = Resume.contentVersion
├── updatedAt
├── usage
├── jobIntent / location
├── education[]
├── workExperience[]
├── projects[]
│   ├── name / role / period / organization
│   ├── details[]         ← 事实证据
│   └── technologies[]
├── skills[]
├── certifications[]
├── languages[]
└── otherEvidence[]
```

Profile 不保存姓名、手机号、邮箱。

非简历拒绝记录也保存在 `Resume.profile`：`validResume: false` 加上 resultId、version、promptVersion、sourceVersion、updatedAt，不作为有效事实 Profile 使用。`isInvalidResume` 按 sourceVersion 与当前内容是否相同判定；更换内容后失效。

`resumeBlockingMessage` 统一检查非简历状态及 `rawText.trim().length > 4000`，UI、任务编排和 Profile 复用均遵守这一条件。超限不是 AI 判定，不需额外持久化字段。

`Job.deepAnalysis` 顶层新增 `isJobDescription` 与 `nonJdReason`。只有当前有效分析明确为 JD，才可建立匹配及下游任务依赖。

有效条件：

```text
profile.version == RESUME_PROFILE_VERSION
profile.promptVersion == PROMPT_VERSIONS.resume_profile
profile.sourceVersion == resume.contentVersion
```

任一不满足，Profile 都视为失效并重新生成。

## 5. Runtime State

```text
state
├── navigation
├── jobs
├── resumeState
│   ├── uploaded
│   ├── parsing
│   ├── understanding
│   ├── profileError
│   └── data
└── tasks
    ├── deepAnalysis
    ├── resumeMatch
    ├── resumeRevision
    └── greeting
```

Match / Revision 仍使用 `idle / loading / success / error` 四态。

## 6. Match dependency

当前 Match 必须同时依赖有效的 Job Profile 与 Resume Profile：

```text
Job Version ─→ Deep Analysis resultId ─┐
                                      ├─→ Match
Resume Version ─→ Resume Profile ID ──┘
```

Match dependency key 包含：

- `jobId / jobVersion`
- `analysisResultId`
- `resumeId / resumeVersion`
- `resumeProfileId / resumeProfileVersion`
- Context / Prompt / Summary 版本

因此 Resume Profile 重新生成后，旧 Match 自动失效。

## 7. Revision / Greeting

Match 成功先持久化。Revision 随后独立运行，失败不删除 Match。
Revision 每条建议保存 `category / summary / original / rewrite / reason`；`category` 用于前端类别标签。

Greeting 依赖当前 Match、Resume、沟通风格（tone）和内容长度档位；模型输入取岗位本质、核心要求、直接匹配证据和可迁移能力。

## 8. Context 限制

- Deep Analysis Raw JD：5000 字符。
- Resume Understanding Raw Resume：4000 字符。
- 常规 Task Context：`contextChars: 12000`。
- Deep Analysis Retry description：3200 字符。

Match 不使用 Raw Resume 的 3000 字 fallback；`resumeChars: 3000` 仅作为历史兼容常量保留，不参与 v2.7.0 正常 Match 路径。

## 9. 结构化隐形要求

`Job.deepAnalysis.hiddenRequirements` 保存 `{ requirement: string, basis: string }[]`；`Job.summary.analysis.inferredRequirements` 保持相同结构供 Match 使用。requirement 为推断要求，basis 为支持该判断的 JD 信息及其与结论的关系，不是候选人证据。

旧字符串数组在存储读取时转换：按第一个“｜”拆分；没有依据则保留空字符串。转换只保留历史数据，不改变原缓存元数据；旧版本分析不会自动升级成有效结果。摘要版本 3、JD 分析 Prompt 5、Match Prompt 9 对旧缓存执行失效保护。

## 托管设置和统计元数据

默认使用 RoleMI 后端；用户保存自己的 Base URL、模型和 API Key 后，优先直连用户的 Responses API（仅支持 Responses API）。项目 Key 不进入扩展 storage；`rolemi.installationId` 为后台首次使用生成的随机 UUID v4；`rolemi.usageQueue` 只存 installation_id/execution_id/module/event/date，最多 200 条/7 天，无业务内容。

D1 ai_calls 保留既有模型/字符数/Token/耗时/状态字段；events 添加 execution_id/module，以 execution_id + event 唯一，同次执行绑定安装/模块/日期，允许乱序到达且只接受首个终态。installations 保留累计匿名实例去重，daily_installations 保留最近 30 天日去重收据，daily_metrics 保留不含实例标识的日计数；每日活跃安装数从 daily_installations 查询，不存在 `__active__` 聚合行。明细保留 30 天，累计匿名标识及聚合持续保留；旧表需一次性 ALTER 迁移，旧测试行不混入新统计。详见 [后端接入说明](backend.md)。

### 服务设置与请求策略

默认使用 RoleMI 后端；用户保存自己的 API 地址、模型名称和 API Key 后，优先直连用户的 Responses API（仅支持 Responses API）。服务设置显示当前服务状态，并提供“恢复默认服务”：清除 local 中的自定义非敏感配置和 session 中的 API Key，立即切回 RoleMI；三个字段全部清空并保存也可恢复。部分填写时拒绝保存。测试、保存和恢复默认互斥执行；local 与 session 无法原子提交，任一写入失败时会以 `Promise.allSettled` 尽力恢复操作前的公开配置和会话 Key，再向界面返回失败。自定义请求失败或会话密钥丢失时提示错误，不自动回退托管。`API_SETTINGS_ENABLED` 当前为 `true`，仅控制入口显示，不影响已保存配置的优先级。

使用事件字段、日期窗口、队列实际清理时机及缓存计数入口见 [metrics.md](metrics.md)。start 之后不保证收到终态；这些元数据不属于岗位或简历内容版本。
